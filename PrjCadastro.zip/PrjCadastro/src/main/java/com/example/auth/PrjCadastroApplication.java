package com.example.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjCadastroApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjCadastroApplication.class, args);
	}

}
